using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor left_back_motor;
extern motor left_front_motor;
extern controller Controller1;
extern rotation rotation_left;
extern rotation rotation_right;
extern motor right_front_motor;
extern motor right_back_motor;
extern motor center_left;
extern motor center_right;
extern motor ringly_dingler;
extern motor mobile_goal;
extern pot mobo_pot;
extern digital_out center_shifter;
extern digital_out drive_speed_shifter;
extern digital_out ring_manipulator;
extern pot Ring_Pot;
extern bumper lift_switch;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );