#include "vex.h"

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// left_back_motor      motor         1               
// left_front_motor     motor         2               
// Controller1          controller                    
// rotation_left        rotation      21              
// rotation_right       rotation      20              
// right_front_motor    motor         3               
// right_back_motor     motor         4               
// Center_Left          motor         5               
// Center_Right         motor         6               
// RinglyDingler        motor         7               
// mobile_goal          motor         8               
// mobo_pot             pot           B               
// inertial_sensor      inertial      9               
// Center_Shifter       digital_out   C               
// Drive_Speed_Shifter  digital_out   D               
// lift_rotation        rotation      13              
// Ring_Manipulator     digital_out   A               
// Ring_Pot             pot           E               
// lift_switch          bumper        F               
// ---- END VEXCODE CONFIGURED DEVICES ----
#include <cmath> //std::abs
#include "Screen.h"
using namespace vex;
competition Competition;

//Settings
double kP = 0.0;
double kI = 0.0;
double kD = 0.0;

//Autonomous Settings
int desiredValue = 0;

int error; //SensorValue - DesiredValue : Position
int prevError = 0; //Position 20 miliseconds ago
int derivative; // error - prevError : Speed
int totalError = 0; //totalError = totalError + error

bool resetDriveSensors = false;

//Variables modified for use
bool enableDrivePID = false;

int drivePID(){
  while(enableDrivePID){
    if (resetDriveSensors) {
      resetDriveSensors = false;
      rotation_left.setPosition(0,rev);
      rotation_right.setPosition(0,rev);
    }

    //Get the position of both rotation sensors
    int leftMotorPosition = rotation_left.position(rev);
    int rightMotorPosition = rotation_right.position(rev);

    //Get average of the two motors
    int averagePosition = (leftMotorPosition + rightMotorPosition)/2;

    //Potential
    error = desiredValue - averagePosition;

    //Derivative
    derivative = error - prevError;

    //Integral
    totalError += error;

    double lateralMotorPower = error * kP + derivative * kD + totalError * kI;

    left_back_motor.spin(forward, lateralMotorPower, voltageUnits::volt);
    right_front_motor.spin(forward, lateralMotorPower, voltageUnits::volt);
    right_back_motor.spin(forward, lateralMotorPower, voltageUnits::volt);
    left_front_motor.spin(forward, lateralMotorPower, voltageUnits::volt);
    
    prevError = error;

    //Enable for actual use, adjust the error based on acceptable range of offness
    /*if( error < 3 and error > -3 ){

    enableDrivePID = false; 
    }*/
    
    vex::task::sleep(20);
  }return 1;
}


//Settings
double liftkP = 0.0;
double liftkI = 0.0;
double liftkD = 0.0;

//Autonomous Settings
int desiredLiftValue = 0;

int lifterror; //SensorValue - DesiredValue : Position
int liftprevError = 0; //Position 20 miliseconds ago
int liftderivative; // error - prevError : Speed
int lifttotalError = 0; //totalError = totalError + error

bool resetLiftSensors = false;

//Variables modified for use
bool enableLiftPID = false;

  int LiftPID(){
  while(enableLiftPID){
    if (resetLiftSensors) {
      resetLiftSensors = false;
      lift_rotation.setPosition(0,rev);
    }

    //Get the position of both rotation sensors
    int leftLiftMotorPosition = rotation_left.position(rev);
    int rightLiftMotorPosition = rotation_right.position(rev);

    //Get average of the two motors
    int averageLiftPosition = (leftLiftMotorPosition + rightLiftMotorPosition)/2;

    //Potential
    lifterror = desiredLiftValue - averageLiftPosition;

    //Derivative
    liftderivative = lifterror - liftprevError;

    //Integral
    lifttotalError += lifterror;

    double liftMotorPower = lifterror * liftkP + liftderivative * liftkD + lifttotalError * liftkI;

    Center_Left.spin(forward, liftMotorPower, voltageUnits::volt);
    Center_Right.spin(forward, liftMotorPower, voltageUnits::volt);
    
    liftprevError = lifterror;

    //Enable for actual use, adjust the error based on acceptable range of offness
    /*if( lifterror < 3 and lifterror > -3 ){

    enableLiftPID = false; 
    }*/
    
    vex::task::sleep(20);
  }return 1;
}
  
//pnuematics
bool pnuematics = false;

//Setting up variables for functions
double wheelDiameterIN  = 3.25; //wheelDiameter is the measurement of a wheel from edge to edge in inches
double circumference = wheelDiameterIN * M_PI; //M_PI is math function that stands for PI

//Drive Functions
///////////////////////////////////////////////////////////////////////////
void DriveStop(){
    left_back_motor.stop(vex::brakeType::brake); 
    right_back_motor.stop(vex::brakeType::brake); 
    right_front_motor.stop(vex::brakeType::brake); 
    left_front_motor.stop(vex::brakeType::brake); 
}

void TimeDrive(int ppower, int Time){ 
    double rvoltage = 12 * (ppower/100);
    left_back_motor.spin(forward, rvoltage, voltageUnits::volt);
    left_front_motor.spin(forward, rvoltage, voltageUnits::volt);
    right_back_motor.spin(forward, rvoltage, voltageUnits::volt);
    right_front_motor.spin(forward, rvoltage, voltageUnits::volt);
    vex::task::sleep(Time); 
    DriveStop();
}

void Drive(int ppower, double Distance){ 
    double rotations = Distance / circumference;
    double rvoltage = 12 * (ppower/100);
    int leftMotorPosition = rotation_left.position(rev);
    int rightMotorPosition = rotation_right.position(rev);
    int averagePosition = (leftMotorPosition + rightMotorPosition)/2;
    while(averagePosition < rotations){
      left_back_motor.spin(forward, rvoltage, voltageUnits::volt);
      left_front_motor.spin(forward, rvoltage, voltageUnits::volt);
      right_back_motor.spin(forward, rvoltage, voltageUnits::volt);
      right_front_motor.spin(forward, rvoltage, voltageUnits::volt);
    }
    DriveStop();
}

void Turn(int ppower, double Distance){
    double rotations = Distance / circumference;
    double rvoltage = 12 * (ppower/100);
    int leftMotorPosition = rotation_left.position(rev);
    int rightMotorPosition = rotation_right.position(rev);
    int averagePosition = (std::abs(leftMotorPosition) + std::abs(rightMotorPosition))/2;
    while(averagePosition < rotations){
      left_back_motor.spin(forward, rvoltage, voltageUnits::volt);
      left_front_motor.spin(forward, rvoltage, voltageUnits::volt);
      right_back_motor.spin(forward, -rvoltage, voltageUnits::volt);
      right_front_motor.spin(forward, -rvoltage, voltageUnits::volt);
    }
    DriveStop();
}

void PIDDrive(int traveldistance){
  resetDriveSensors = true;
  int DesiredRotations = traveldistance /circumference;
  desiredValue = DesiredRotations;
  enableDrivePID = true;
  vex::task Drive(drivePID);
  while(enableDrivePID == true){
    vex::task::sleep(10);
  }
  DriveStop();
}
///////////////////////////////////////////////////////////////////////////

//Lift Functions
///////////////////////////////////////////////////////////////////////////
void StopLift(){
  Center_Left.stop(vex::brakeType::brake); 
  Center_Right.stop(vex::brakeType::brake); 
}

void LiftDown(){
  while(lift_switch.pressing() == false){
    Center_Left.spin(forward, -12, voltageUnits::volt);
    Center_Right.spin(forward, -12, voltageUnits::volt);
  }
  StopLift();
}

void Lift(int ppower){
  double rvoltage = 12 * (ppower/100);
  Center_Left.spin(forward, rvoltage, voltageUnits::volt);
  Center_Right.spin(forward, rvoltage, voltageUnits::volt);
}

void TimedLift(int ppower, int time){
  double rvoltage = 12 * (ppower/100);
  Center_Left.spin(forward, rvoltage, voltageUnits::volt);
  Center_Right.spin(forward, rvoltage, voltageUnits::volt);
  vex::task::sleep(time);
  StopLift();
}

void PIDLift(int traveldistance){
  resetLiftSensors = true;
  desiredLiftValue = traveldistance;
  enableLiftPID = true;
  vex::task Lift(LiftPID);
  while(enableDrivePID == true){
    vex::task::sleep(10);
  }
  DriveStop();
}
///////////////////////////////////////////////////////////////////////////

//Mobile Goal Functions
///////////////////////////////////////////////////////////////////////////
void MobileGoalUp(){
  while(mobo_pot.angle(vex::percentUnits::pct) < 10){
    mobile_goal.spin(forward, 12, voltageUnits::volt);
  }
  mobile_goal.stop(vex::brakeType::coast); 
}

void MobileGoalDown(){
  while(mobo_pot.angle(vex::percentUnits::pct) > 10){
    mobile_goal.spin(forward, -12, voltageUnits::volt);
  }
  mobile_goal.stop(vex::brakeType::coast); 
}
///////////////////////////////////////////////////////////////////////////
 

// Pre Auton Variables
int Pre = 0;
double tileselect = 0;
int SideSelect = 0;
double Screen = 0;
double ProgSelect = 0;
int squareselect = 0;

void pre_auton( void ) {
 	while(Pre==0){
 		if(Screen == 0){
 			Brain.Screen.clearScreen();
      TextChanger(2);
 			Brain.Screen.setPenWidth(2);
 			Brain.Screen.setPenColor(vex::color::blue);
 			Brain.Screen.drawRectangle(165,10,300,220,vex::color::black);
 			Brain.Screen.drawLine(175,60,455,60);
 			Brain.Screen.drawRectangle(175,75,280,65,vex::color::black);
 			Brain.Screen.drawRectangle(175,155,280,65,vex::color::black);
      Brain.Screen.drawRectangle(400,20,55,30,vex::color::black);
 			Brain.Screen.setFont(vex::fontType::prop30);
 			Brain.Screen.setPenColor("#C0C0C0");
 			Brain.Screen.printAt(190,50,false,"Home");
      Brain.Screen.printAt(190,112,false,"Autonomous Select");
 			Brain.Screen.printAt(192,195,false,"System Diagnostics");
 			Brain.Screen.setFont(vex::fontType::prop20);
      Brain.Screen.printAt(415,40,false,"Set");
      vex::task::sleep(500);
 			while(Screen == 0){
 				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 140 && Brain.Screen.yPosition() >75 && Brain.Screen.xPosition() < 455 && Brain.Screen.xPosition() > 175){
 					Screen = 2;
 				}
 				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 220 && Brain.Screen.yPosition() >155 && Brain.Screen.xPosition() < 455 && Brain.Screen.xPosition() > 175){
 					Screen = 3;
 				}
         if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 50 && Brain.Screen.yPosition() >20 && Brain.Screen.xPosition() < 455 && Brain.Screen.xPosition() > 400){
           Brain.Screen.clearScreen();
           Pre = 1;
           break;
 				}
 			}
 		}
 		if(Screen == 2){ //Program Select Screen
 			Brain.Screen.clearScreen();
 			Brain.Screen.setPenWidth(2);
 			Brain.Screen.setPenColor(vex::color::blue);
 			Brain.Screen.drawRectangle(165,10,300,220,vex::color::black);
 			Brain.Screen.drawLine(175,60,455,60);
 			Brain.Screen.drawRectangle(175,75,135,65,vex::color::black);
 			Brain.Screen.drawRectangle(175,155,135,65,vex::color::black);
 			Brain.Screen.setFont(vex::fontType::prop20);
 			Brain.Screen.setPenColor("#C0C0C0");
 			Brain.Screen.drawRectangle(425,20,30,30,vex::color::black);
 			Brain.Screen.printAt(225,105,false,"Blue");
 			Brain.Screen.printAt(210,125,false,"Alliance");
 			Brain.Screen.printAt(225,185,false,"Red");
 			Brain.Screen.printAt(210,205,false,"Alliance");
 			Brain.Screen.setFont(vex::fontType::prop30);
 			Brain.Screen.printAt(190,50,false,"Auto Select");
 			Brain.Screen.setPenColor(vex::color::red);
 			Brain.Screen.setPenWidth(4);
 			Brain.Screen.drawLine(435,35,445,25);
 			Brain.Screen.drawLine(435,35,445,45);
 			vex::task::sleep(500);
 			while(Screen == 2 ){
 				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 50 && Brain.Screen.yPosition() >20 && Brain.Screen.xPosition() <455 && Brain.Screen.xPosition() > 425){//Exit?
 					Screen = 0;
 					SideSelect = 0;
 				}
 				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 140 && Brain.Screen.yPosition() >75 && Brain.Screen.xPosition() <310 && Brain.Screen.xPosition() > 175 && SideSelect != 1){ //Blue side select
 					SideSelect = 1;
          tileselect = 0;
 					BlueAuto();
 				}
 				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 220 && Brain.Screen.yPosition() >155 && Brain.Screen.xPosition() <310 && Brain.Screen.xPosition() > 175 && SideSelect != 2){ //Red side select
 					SideSelect = 2;
          tileselect = 0;
 					RedAuto();
 				}
 				if(Brain.Screen.pressing() == true && tileselect != 1 && SideSelect == 1 && Brain.Screen.yPosition() < 81 && Brain.Screen.yPosition() >42 && Brain.Screen.xPosition() <160 && Brain.Screen.xPosition() > 111){ //Blue front poition 
 					tileselect = 1;
 					BlueAuto();
          AutoSelectB();
          BTF();
 					Brain.Screen.setPenWidth(2);
 					Brain.Screen.setPenColor(vex::color::green);
 					Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
 				}
 				if(Brain.Screen.pressing() == true && tileselect != 2 && SideSelect == 1 && Brain.Screen.yPosition() < 198 && Brain.Screen.yPosition() >159 && Brain.Screen.xPosition() <160 && Brain.Screen.xPosition() > 111){ //Blue back position 
 					tileselect = 2;
 					BlueAuto();
          AutoSelectB();
          BBF();
 					Brain.Screen.setPenWidth(2);
 					Brain.Screen.setPenColor(vex::color::green);
 					Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
 				}
 				if(Brain.Screen.pressing() == true && tileselect != 3 && SideSelect == 2 && Brain.Screen.yPosition() < 81 && Brain.Screen.yPosition() >42 && Brain.Screen.xPosition() <160 && Brain.Screen.xPosition() > 111){ //Red fron position
 					tileselect = 3;
 					RedAuto();
                     AutoSelectR();
                     RTF();
 					Brain.Screen.setPenWidth(2);
 					Brain.Screen.setPenColor(vex::color::green);
 					Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
 				}
 				if(Brain.Screen.pressing() == true && tileselect != 4 && SideSelect == 2 && Brain.Screen.yPosition() < 198 && Brain.Screen.yPosition() >159 && Brain.Screen.xPosition() <160 && Brain.Screen.xPosition() > 111){ //Red back position
 					tileselect = 4;
 					RedAuto();
                     AutoSelectR();
                     RBF();
 					Brain.Screen.setPenWidth(2);
 					Brain.Screen.setPenColor(vex::color::green);
 					Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
 				}
        if(Brain.Screen.pressing() == true && squareselect != 1&& Brain.Screen.yPosition() < 110 && Brain.Screen.yPosition() >74 && Brain.Screen.xPosition() <455 && Brain.Screen.xPosition() > 320){ //Selecting top auto 
                     squareselect = 1;
                     if(tileselect == 1){ //Top blue tile 1st auto
                         BlueAuto();
                         ProgSelect = 1.1;
                         AutoSelectB(); 
                         BTF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                     }
                     if(tileselect == 2){  //Bot blue tile 1st auto
                         BlueAuto();
                         ProgSelect = 1.2;
                         AutoSelectB();
                         BBF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                     }
                     if(tileselect == 3){ //Top red tile 1st auto
                         RedAuto();
                         ProgSelect = 1.3;
                         AutoSelectR();
                         RTF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                     }
                     if(tileselect == 4){  //Top blue tile 1st auto
                         RedAuto();
                         ProgSelect = 1.4;
                         AutoSelectR();
                         RBF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                     }
                     Brain.Screen.setPenWidth(2);
 					Brain.Screen.setPenColor(vex::color::green);
 					Brain.Screen.drawRectangle(320,74,134,36,vex::color::transparent);
                 }
                 if(Brain.Screen.pressing() == true  && squareselect != 2&& Brain.Screen.yPosition() < 147 && Brain.Screen.yPosition() >110 && Brain.Screen.xPosition() <455 && Brain.Screen.xPosition() > 320){ //Selecting 2nd auto
                     squareselect = 2;
                     if(tileselect == 1){ //Top blue tile 2nd auto
                         BlueAuto();
                         ProgSelect = 2.1;
                         AutoSelectB();
                         BTF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                     }
                     if(tileselect == 2){  //Bot blue tile 2nd auto
                         BlueAuto();
                         ProgSelect = 2.2;
                         AutoSelectB();
                         BBF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                     }
                     if(tileselect == 3){ //Top red tile 2nd auto
                         RedAuto();
                         ProgSelect = 2.3;
                         AutoSelectR();
                         RTF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                     }
                     if(tileselect == 4){  //Bot red tile 2nd auto
                         RedAuto();
                         ProgSelect = 2.4;
                         AutoSelectR();
                         RBF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                     }
                     Brain.Screen.setPenWidth(2);
 					Brain.Screen.setPenColor(vex::color::green);
 					Brain.Screen.drawRectangle(320,110,134,36,vex::color::transparent);
                 }
                 if(Brain.Screen.pressing() == true  && squareselect != 3 && Brain.Screen.yPosition() < 185 && Brain.Screen.yPosition() >147 && Brain.Screen.xPosition() <455 && Brain.Screen.xPosition() > 320){ //Selecting 3rd auto
                    squareselect = 3;
                     if(tileselect == 1){ //Top blue tile 3rd auto
                         BlueAuto();
                         ProgSelect = 3.1;
                         AutoSelectB();
                         BTF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                     }
                     if(tileselect == 2){  //Bot blue tile 3rd auto
                         BlueAuto();
                         ProgSelect = 3.2;
                         AutoSelectB();
                         BBF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                     }
                     if(tileselect == 3){ //Top red tile 3rd auto
                         RedAuto();
                         ProgSelect = 3.3;
                         AutoSelectR();
                         RTF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                     }
                     if(tileselect == 4){  //Bot blue tile 3rd auto
                         RedAuto();
                         ProgSelect = 3.4;
                         AutoSelectR();
                         RBF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                     }
                     Brain.Screen.setPenWidth(2);
 					Brain.Screen.setPenColor(vex::color::green);
 					Brain.Screen.drawRectangle(320,147,134,36,vex::color::transparent);
                 }
                 if(Brain.Screen.pressing() == true && squareselect != 4&& Brain.Screen.yPosition() < 215 && Brain.Screen.yPosition() >185 && Brain.Screen.xPosition() <455 && Brain.Screen.xPosition() > 320){ //Selecting bottom auto 
                     squareselect = 4;
                     if(tileselect == 1){ //Top blue tile bottom auto
                         BlueAuto();
                         ProgSelect = 4.1;
                         AutoSelectB();
                         BTF();
                         Brain.Screen.setPenWidth(2);
 					               Brain.Screen.setPenColor(vex::color::green);
 					               Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                     }
                     if(tileselect == 2){ //Bot blue tile bottom auto
                         BlueAuto();
                         ProgSelect = 4.2;
                         AutoSelectB();
                         BBF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                     }
                     if(tileselect == 3){  //Top red tile bottom auto
                         RedAuto();
                         ProgSelect = 4.3;
                         AutoSelectR();
                         RTF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                     }
                     if(tileselect == 4){ //Bottom red tile bottom auto 
                         RedAuto();
                         ProgSelect = 4.4;
                         AutoSelectR();
                         RBF();
                         Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                     }
                     Brain.Screen.setPenWidth(2);
 					    Brain.Screen.setPenColor(vex::color::green);
 					Brain.Screen.drawRectangle(320,185,134,36,vex::color::transparent);
                 }
 			}
 		}
 		if(Screen == 3){ //Settings Screen
 			while(Screen == 3){
 		}
 		}
 	}
 }

 //Autonomus Function
 void autonomous( void ) { 
    vex::task Drive(drivePID);
    resetDriveSensors = true;
    desiredValue = 300;

    /*if(ProgSelect == 1.1){ Front Blue 1
    }
    if(ProgSelect == 2.1){Front Blue 2
    }
    if(ProgSelect == 3.1){Front Blue 3
 
    }
    if(ProgSelect == 4.1){Front Blue 4
 
    }
    if(ProgSelect == 1.2){Back Blue 1
    }
    if(ProgSelect == 2.2){Back Blue 2
 
    }
    if(ProgSelect == 3.2){Back Blue 3
 
    }
    if(ProgSelect == 4.2){Back Blue 4
      
    }
    if(ProgSelect == 1.3){Front Red 1
    }
    if(ProgSelect == 2.3){Front Red 2
 
    }
    if(ProgSelect == 3.3){Front Red 3
 
    }
    if(ProgSelect == 4.3){ Front Red 4
 
    }
    if(ProgSelect == 1.4){Back Red 1
    }
    if(ProgSelect == 2.4){Back Red 2
      
    }
    if(ProgSelect == 3.4){Back Red 3
 
    }
    if(ProgSelect == 4.4){Back Red 4
 
    }*/
 }
 
 void usercontrol( void ) { 
  //Drivetrain
  double turnImportance = 0.5;

  while (1) {
    //Drive Control
    ///////////////////////////////////////////////////////////////////////////
    double turnVal = Controller1.Axis4.position(percent);
    double forwardVal = Controller1.Axis3.position(percent);
    double turnVolts = turnVal * 0.12;
    double forwardVolts = forwardVal * 0.12 * (1 - (std::abs(turnVolts)/12.0) * turnImportance);

    left_back_motor.spin(forward, forwardVolts + turnVolts, voltageUnits::volt);
    left_front_motor.spin(forward, forwardVolts + turnVolts, voltageUnits::volt);
    right_back_motor.spin(forward, forwardVolts - turnVolts, voltageUnits::volt);
    right_front_motor.spin(forward, forwardVolts - turnVolts, voltageUnits::volt);
    ///////////////////////////////////////////////////////////////////////////
    
    //Lift Control
    ///////////////////////////////////////////////////////////////////////////
    if (Controller1.ButtonL1.pressing()){
      Center_Left.spin(forward, 12.0, voltageUnits::volt);
      Center_Right.spin(forward, 12.0, voltageUnits::volt);
    }
    else if (Controller1.ButtonL2.pressing()){
      Center_Left.spin(forward, -12.0, voltageUnits::volt);
      Center_Right.spin(forward, -12.0, voltageUnits::volt);
    }
    else{
      Center_Left.stop(vex::brakeType::brake);
      Center_Right.stop(vex::brakeType::brake);
    }
    ///////////////////////////////////////////////////////////////////////////

    //Mobile Goal Control
    ///////////////////////////////////////////////////////////////////////////
    if (Controller1.ButtonUp.pressing()){
      mobile_goal.spin(forward, 12.0, voltageUnits::volt);
    }
    else if (Controller1.ButtonDown.pressing()){
      mobile_goal.spin(forward, -12.0, voltageUnits::volt);
    }
    else{
      mobile_goal.stop(vex::brakeType::brake);
    }
    ///////////////////////////////////////////////////////////////////////////
    wait(10, msec);
   }
}
 
 int main() {
     vexcodeInit();
     Competition.autonomous( autonomous );
     Competition.drivercontrol( usercontrol ); 
     pre_auton();                       
     while(1) {
       vex::task::sleep(100);
     }    
        
 }
 