using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor left_back_motor;
extern motor left_front_motor;
extern controller Controller1;
extern rotation rotation_left;
extern rotation rotation_right;
extern motor right_front_motor;
extern motor right_back_motor;
extern motor lift_left;
extern motor lift_right;
extern motor intake;
extern motor mobile_goal;
extern pot mobo_potentiometer;
extern inertial inertial_sensor;
extern digital_out pnuematic_left;
extern digital_out pnuematic_right;
extern distance intake_top;
extern distance intake_counter;
extern pot claw_potentiometer;
extern rotation lift_left_rotation;
extern rotation lift_right_rotation;
extern bumper lift_switch;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );