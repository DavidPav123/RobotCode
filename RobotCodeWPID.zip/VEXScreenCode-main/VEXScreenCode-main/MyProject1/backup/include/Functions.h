#include "Screen.h"
using namespace vex;
//Feeder Functions
void IFeed(){
   LFeed.spin(vex::directionType::rev,200,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
    RFeed.spin(vex::directionType::fwd,200,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
}

void OFeed(){
    LFeed.spin(vex::directionType::fwd,200,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
    RFeed.spin(vex::directionType::rev,200,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
}
void SFeed(){
    LFeed.stop(vex::brakeType::brake); //Stop Left Lift 
    RFeed.stop(vex::brakeType::brake); //Stop Right Lift 
}

void UTilt(int height, int power){
    while(TiltPot.value(vex::percentUnits::pct) >= height){
        Tilt.spin(vex::directionType::fwd,power,vex::velocityUnits::rpm); //Run Left Lift reversed at 100 rpm 
    }
    Tilt.stop(vex::brakeType::brake); //Stop Left Lift 
}
//Lift Functions
void ULift(int height, int power){
    while(Pot.value(vex::percentUnits::pct) <= height){
        LL.spin(vex::directionType::rev,power,vex::velocityUnits::rpm); //Run Left Lift reversed at 100 rpm 
        RL.spin(vex::directionType::fwd,power,vex::velocityUnits::rpm);  //Run Right lift reversed at 100 rpm   
    }
    LL.stop(vex::brakeType::brake); //Stop Left Lift 
    RL.stop(vex::brakeType::brake); //Stop Right Lift
}
void DLift(int height, int power){
    while(Pot.value(vex::percentUnits::pct) >= height){
        LL.spin(vex::directionType::fwd,power,vex::velocityUnits::rpm); //Run Left Lift reversed at 100 rpm 
        RL.spin(vex::directionType::rev,power,vex::velocityUnits::rpm);  //Run Right lift reversed at 100 rpm   
    }
    LL.stop(vex::brakeType::brake); //Stop Left Lift 
    RL.stop(vex::brakeType::brake); //Stop Right Lift 
}
//Drive Funtions
void TDFFP(int Time){ //Define TimeDriveForward with intiger variable "Time"
    CW.spin(vex::directionType::rev,200,vex::velocityUnits::rpm); //Run Left Front motor at 50 rpm
    LB.spin(vex::directionType::fwd,200,vex::velocityUnits::rpm); //Run Left Back motor at 50 rpm
    RB.spin(vex::directionType::rev,200,vex::velocityUnits::rpm); //Run Right Back motor at 50 rpm
    vex::task::sleep(Time); //Stop any code from executing for set "Time"
    CW.stop(vex::brakeType::coast); //Stop Left Front motor
    LB.stop(vex::brakeType::coast); //Stop Left Back motor
    RB.stop(vex::brakeType::coast); //Stop Right Back motor
}
void TDF(int Time){ //Define TimeDriveForward with intiger variable "Time"
    CW.spin(vex::directionType::rev,50,vex::velocityUnits::rpm); //Run Left Front motor at 50 rpm
    LB.spin(vex::directionType::fwd,50,vex::velocityUnits::rpm); //Run Left Back motor at 50 rpm
    RB.spin(vex::directionType::rev,50,vex::velocityUnits::rpm); //Run Right Back motor at 50 rpm
    vex::task::sleep(Time); //Stop any code from executing for set "Time"
    CW.stop(vex::brakeType::coast); //Stop Left Front motor
    LB.stop(vex::brakeType::coast); //Stop Left Back motor
    RB.stop(vex::brakeType::coast); //Stop Right Back motor
}
void TDR(int Time){ //Define TimeDriveForward with intiger variable "Time"
    CW.spin(vex::directionType::fwd,50,vex::velocityUnits::rpm); //Run Left Front motor at 50 rpm
    LB.spin(vex::directionType::rev,50,vex::velocityUnits::rpm); //Run Left Back motor at 50 rpm
    RB.spin(vex::directionType::fwd,50,vex::velocityUnits::rpm); //Run Right Back motor at 50 rpm
    vex::task::sleep(Time); //Stop any code from executing for set "Time"
    CW.stop(vex::brakeType::coast); //Stop Left Front motor
    LB.stop(vex::brakeType::coast); //Stop Left Back motor
    RB.stop(vex::brakeType::coast); //Stop Right Back motor
}
void DStop(){
    CW.stop(vex::brakeType::brake); //Stop Left Front motor
    LB.stop(vex::brakeType::brake); //Stop Left Back motor
    RB.stop(vex::brakeType::brake); //Stop Right Back motor    
}
void Drive(int Power, double Distance){ //Define Function "Drive" with intiger variable "power" and double variable "Distance"
    double wheelDiameterIN  = 4; //wheelDiameter is the measurement of a wheel from edge to edge in inches 
    double circumference = wheelDiameterIN * M_PI; //M_PI is math function that stands for PI
    double degreesToRotate= (360 * Distance) / circumference; //Calculate how many the Left motors need to rotate to reach inputed distance
    CW.rotateFor(-degreesToRotate, vex::rotationUnits::deg, Power, vex::velocityUnits::rpm,false); //Run Right Front motor for a set rotations to reach distance and at a set rpm
    RB.rotateFor(-degreesToRotate, vex::rotationUnits::deg, Power, vex::velocityUnits::rpm,false); //Run Right Back motor for a set rotations to reach distance and at a set rpm
    LB.rotateFor(degreesToRotate, vex::rotationUnits::deg, Power, vex::velocityUnits::rpm); //Run Left back motor for a set rotations to reach distance and at a set rpm
    CW.stop(vex::brakeType::brake); //Stop Left Front Drive Motor
    RB.stop(vex::brakeType::brake); //Stop Right Back Drive motor
    LB.stop(vex::brakeType::brake); //Stop Left Back Drive Motor
}
void Turn(int Power, double Distance){ //Define Function "Turn" with intiger variable "power" and double variable "Distance"
    double wheelDiameterIN  = 4; //wheelDiameter is the measurement of a wheel from edge to edge in inches 
    double circumference = wheelDiameterIN * M_PI; //M_PI is math function that stands for PI
    double degreesToRotate= (360 * Distance) / circumference; //Calculate how many the Left motors need to rotate to reach inputed distance
    RB.rotateFor(degreesToRotate, vex::rotationUnits::deg, Power, vex::velocityUnits::rpm,false); //Run Right Back motor for a set rotations to reach distance and at a set rpm
    LB.rotateFor(degreesToRotate, vex::rotationUnits::deg, Power, vex::velocityUnits::rpm); //Run Left back motor for a set rotations to reach distance and at a set rpm
    RB.stop(vex::brakeType::brake); //Stop Right Back Drive motor
    LB.stop(vex::brakeType::brake); //Stop Left Back Drive Motor
}