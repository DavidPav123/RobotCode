#include "vex.h"

// A global instance of vex::competition
vex::competition Competition;
//Initiates Brain
vex::brain Brain;
//Initiates controller
vex::controller Controller1 = vex::controller();
//Initiates Right Front Drive motor on port 3 with speed gear ratio and not reversed
vex::motor CW = vex::motor(vex::PORT17,vex::gearSetting::ratio18_1,true);
//Initiates Right Back Drive motor on port 1 with speed gear ratio and not reversed
vex::motor RB = vex::motor(vex::PORT19,vex::gearSetting::ratio18_1,false);
//Initiates Left Back Drive motor on port 10 with speed gear ratio and not reversed
vex::motor LB = vex::motor(vex::PORT14,vex::gearSetting::ratio18_1,false);
//Initiate Left Lift Drive motor on port 13 with torque gear ratio and not reversed
vex::motor LL = vex::motor(vex::PORT13,vex::gearSetting::ratio36_1,false);
//Initiates Right Lift Drive motor on port 20 with torque gear ratio and reversed
vex::motor RL = vex::motor(vex::PORT16,vex::gearSetting::ratio36_1,false);
//Initiates Feed Drive motor on port 11 with speed gear ratio and not reversed
vex::motor RFeed = vex::motor(vex::PORT18,vex::gearSetting::ratio18_1,false);
//Initiates Tilter Front Drive motor on port 19 with speed gear ratio and not reversed
vex::motor LFeed = vex::motor(vex::PORT15,vex::gearSetting::ratio18_1,false);
vex::motor Tilt = vex::motor(vex::PORT12,vex::gearSetting::ratio36_1,false);
//Initiates a VEX potentiomiter
vex::pot Pot = vex::pot(Brain.ThreeWirePort.A);
//Initiates a VEX potentiomiter
vex::pot TiltPot = vex::pot(Brain.ThreeWirePort.B);

void RTF(){
  Brain.Screen.printAt(350,105,false,"3C");
  Brain.Screen.printAt(330,142,false,"");
  Brain.Screen.printAt(330,180,false,"");
  Brain.Screen.printAt(330,216,false,"");   
}
void RBF(){
  Brain.Screen.printAt(350,105,false,"T->C");
  Brain.Screen.printAt(350,142,false,"");
  Brain.Screen.printAt(350,180,false,"");
  Brain.Screen.printAt(350,216,false,"");
}
void BBF(){
  Brain.Screen.printAt(350,105,false,"T->C");
  Brain.Screen.printAt(350,142,false,"");
  Brain.Screen.printAt(350,180,false,"");
  Brain.Screen.printAt(350,216,false,"");
}
void BTF(){
  Brain.Screen.printAt(350,105,false,"3C");
  Brain.Screen.printAt(330,142,false,"");
  Brain.Screen.printAt(330,180,false,"");
  Brain.Screen.printAt(330,216,false,"");
}
void AutoSelectR(){
  Brain.Screen.setPenWidth(1);
	Brain.Screen.setPenColor(vex::color::red);
  Brain.Screen.drawRectangle(320,74,135,148,vex::color::black);
  Brain.Screen.drawLine(320,110,455,110);
  Brain.Screen.drawLine(320,147,455,147);
  Brain.Screen.drawLine(320,185,455,185);
  Brain.Screen.setPenColor("#C0C0C0");
  Brain.Screen.setFont(vex::fontType::prop30);
  Brain.Screen.printAt(322,105,false,"1.");
  Brain.Screen.printAt(322,142,false,"2.");
  Brain.Screen.printAt(322,180,false,"3.");
  Brain.Screen.printAt(322,216,false,"4.");
}
void AutoSelectB(){
  Brain.Screen.setPenWidth(1);
	Brain.Screen.setPenColor(vex::color::blue);
  Brain.Screen.drawRectangle(320,74,135,148,vex::color::black);
  Brain.Screen.drawLine(320,110,455,110);
  Brain.Screen.drawLine(320,147,455,147);
  Brain.Screen.drawLine(320,185,455,185);
  Brain.Screen.setPenColor("#C0C0C0");
  Brain.Screen.setFont(vex::fontType::prop30);
  Brain.Screen.printAt(322,105,false,"1.");
  Brain.Screen.printAt(322,142,false,"2.");
  Brain.Screen.printAt(322,180,false,"3.");
  Brain.Screen.printAt(322,216,false,"4.");
}

void BlueAuto(){
	Brain.Screen.clearScreen("#383838");
	Brain.Screen.setPenWidth(2);
	Brain.Screen.setPenColor(vex::color::blue);
	Brain.Screen.drawRectangle(165,10,300,220,vex::color::black);
	Brain.Screen.drawLine(175,60,455,60);
	Brain.Screen.drawRectangle(175,75,135,65,vex::color::blue);
	Brain.Screen.drawRectangle(175,155,135,65,vex::color::black);
	Brain.Screen.setPenColor("#C0C0C0");
	Brain.Screen.drawRectangle(425,20,30,30,vex::color::black);
	Brain.Screen.setFont(vex::fontType::prop20);
	Brain.Screen.printAt(225,105,false,"Blue");
	Brain.Screen.printAt(210,125,false,"Alliance");
	Brain.Screen.printAt(225,185,false,"Red");
	Brain.Screen.printAt(210,205,false,"Alliance");
	Brain.Screen.setFont(vex::fontType::prop30);
	Brain.Screen.printAt(190,50,false,"Auto Select");
	Brain.Screen.setPenColor(vex::color::red);
	Brain.Screen.setPenWidth(4);
	Brain.Screen.drawLine(435,35,445,25);
	Brain.Screen.drawLine(435,35,445,45);
	Brain.Screen.setPenColor(vex::color::black);
	Brain.Screen.setPenWidth(1);
	Brain.Screen.drawRectangle(1,2,159,235,vex::color::transparent);
	Brain.Screen.drawLine(1,42,160,42);
	Brain.Screen.drawLine(1,81,160,81);
	Brain.Screen.drawLine(1,120,160,120);
	Brain.Screen.drawLine(1,159,160,159);
	Brain.Screen.drawLine(1,198,160,198);
	Brain.Screen.drawLine(56,2,56,236);
	Brain.Screen.drawLine(111,2,111,236);
	Brain.Screen.drawRectangle(56,2,56,42,vex::color::blue);
	Brain.Screen.drawRectangle(111,42,49,40,vex::color::blue);
	Brain.Screen.setPenWidth(2);
	Brain.Screen.drawCircle(111,120,15,vex::color::transparent);
	Brain.Screen.drawCircle(1,61,15,vex::color::transparent);
	Brain.Screen.drawCircle(1,120,15,vex::color::transparent);
	Brain.Screen.drawCircle(1,178,15,vex::color::transparent);
	Brain.Screen.drawCircle(83,236,15,vex::color::blue);
	Brain.Screen.setPenColor(vex::color::blue);
	Brain.Screen.setPenWidth(1);
	Brain.Screen.drawLine(125,3,125,20);
	Brain.Screen.drawLine(125,20,158,20);
	Brain.Screen.drawLine(140,214,140,235);
	Brain.Screen.drawLine(140,214,158,214);
}
void RedAuto(){
	Brain.Screen.clearScreen("#383838");
	Brain.Screen.setPenWidth(2);
	Brain.Screen.setPenColor(vex::color::blue);
	Brain.Screen.drawRectangle(165,10,300,220,vex::color::black);
	Brain.Screen.drawLine(175,60,455,60);
	Brain.Screen.drawRectangle(175,75,135,65,vex::color::black);
	Brain.Screen.drawRectangle(175,155,135,65,vex::color::red);
	Brain.Screen.setPenColor("#C0C0C0");
	Brain.Screen.drawRectangle(425,20,30,30,vex::color::black);
	Brain.Screen.setFont(vex::fontType::prop20);
	Brain.Screen.printAt(225,105,false,"Blue");
	Brain.Screen.printAt(210,125,false,"Alliance");
	Brain.Screen.printAt(225,185,false,"Red");
	Brain.Screen.printAt(210,205,false,"Alliance");
	Brain.Screen.setFont(vex::fontType::prop30);
	Brain.Screen.printAt(190,50,false,"Auto Select");
	Brain.Screen.setPenColor(vex::color::red);
	Brain.Screen.setPenWidth(4);
	Brain.Screen.drawLine(435,35,445,25);
	Brain.Screen.drawLine(435,35,445,45);
	Brain.Screen.setPenColor(vex::color::black);
	Brain.Screen.setPenWidth(1);
	Brain.Screen.drawRectangle(1,2,159,235,vex::color::transparent);
	Brain.Screen.drawLine(1,42,160,42);
	Brain.Screen.drawLine(1,81,160,81);
	Brain.Screen.drawLine(1,120,160,120);
	Brain.Screen.drawLine(1,159,160,159);
	Brain.Screen.drawLine(1,198,160,198);
	Brain.Screen.drawLine(56,2,56,236);
	Brain.Screen.drawLine(111,2,111,236);
	Brain.Screen.drawRectangle(56,2,56,42,vex::color::red);
	Brain.Screen.drawRectangle(111,42,49,40,vex::color::red);
	Brain.Screen.setPenWidth(2);
	Brain.Screen.drawCircle(111,120,15,vex::color::transparent);
	Brain.Screen.drawCircle(1,61,15,vex::color::transparent);
	Brain.Screen.drawCircle(1,120,15,vex::color::transparent);
	Brain.Screen.drawCircle(1,178,15,vex::color::transparent);
	Brain.Screen.drawCircle(83,236,15,vex::color::red);
	Brain.Screen.setPenColor(vex::color::red);
	Brain.Screen.setPenWidth(1);
	Brain.Screen.drawLine(125,3,125,20);
	Brain.Screen.drawLine(125,20,158,20);
	Brain.Screen.drawLine(140,214,140,235);
	Brain.Screen.drawLine(140,214,158,214);
}
void TextChanger(int pencolour){
	if(pencolour == 0){
		Brain.Screen.setPenColor("#C0C0C0");
	}
	if(pencolour == 1){
		Brain.Screen.setPenColor(vex::color::blue);
	}
	if(pencolour == 2){
		Brain.Screen.setPenColor("#FFD700");
	}
  //4
	Brain.Screen.setPenWidth(5);
	Brain.Screen.drawLine(40,10,70,10);
	Brain.Screen.drawLine(10,35,10,65);
	Brain.Screen.drawLine(40,10,10,35);
	Brain.Screen.drawLine(10,65,40,65);
	Brain.Screen.drawLine(70,10,70,45);
	Brain.Screen.drawLine(20,65,40,65);
	Brain.Screen.drawLine(70,45,85,45);
	Brain.Screen.drawLine(85,45,85,65);
	Brain.Screen.drawLine(65,65,85,65);
	Brain.Screen.drawLine(65,65,65,85);
	Brain.Screen.drawLine(40,65,40,85);
	Brain.Screen.drawLine(40,85,65,85);
	Brain.Screen.drawLine(50,30,50,50);
	Brain.Screen.drawLine(30,50,50,50);
	Brain.Screen.drawLine(30,49,49,29);
//4
	Brain.Screen.drawLine(110,60,140,60);
	Brain.Screen.drawLine(80,85,80,115);
	Brain.Screen.drawLine(110,60,80,85);
	Brain.Screen.drawLine(80,115,110,115);
	Brain.Screen.drawLine(140,60,140,95);
	Brain.Screen.drawLine(90,115,110,115);
	Brain.Screen.drawLine(140,95,155,95);
	Brain.Screen.drawLine(155,95,155,115);
	Brain.Screen.drawLine(135,115,155,115);
	Brain.Screen.drawLine(135,115,135,135);
	Brain.Screen.drawLine(110,115,110,135);
	Brain.Screen.drawLine(110,135,135,135);
	Brain.Screen.drawLine(120,80,120,100);
	Brain.Screen.drawLine(100,100,120,100);
	Brain.Screen.drawLine(100,99,119,79);
//4
	Brain.Screen.drawLine(40,110,70,110);
	Brain.Screen.drawLine(10,135,10,165);
	Brain.Screen.drawLine(40,110,10,135);
	Brain.Screen.drawLine(10,165,40,165);
	Brain.Screen.drawLine(70,110,70,145);
	Brain.Screen.drawLine(20,165,40,165);
	Brain.Screen.drawLine(70,145,85,145);
	Brain.Screen.drawLine(85,145,85,165);
	Brain.Screen.drawLine(65,165,85,165);
	Brain.Screen.drawLine(65,165,65,185);
	Brain.Screen.drawLine(40,165,40,185);
	Brain.Screen.drawLine(40,185,65,185);
	Brain.Screen.drawLine(50,130,50,150);
	Brain.Screen.drawLine(30,150,50,150);
	Brain.Screen.drawLine(30,149,49,129);
  //2
	Brain.Screen.drawLine(105,160,135,160);
	Brain.Screen.drawLine(90,170,90,185);
	Brain.Screen.drawLine(105,160,90,170);
	Brain.Screen.drawLine(135,160,150,170);
	Brain.Screen.drawLine(150,170,150,190);
	Brain.Screen.drawLine(90,235,150,235);
	Brain.Screen.drawLine(90,220,90,235);
	Brain.Screen.drawLine(150,220,150,235);
	Brain.Screen.drawLine(120,220,150,220);
	Brain.Screen.drawLine(120,220,149,190);
	Brain.Screen.drawLine(90,185,110,185);
	Brain.Screen.drawLine(110,175,110,185);
	Brain.Screen.drawLine(110,175,125,175);
	Brain.Screen.drawLine(125,175,125,185);
	Brain.Screen.drawLine(125,185,90,220);
}