/*
#include "Functions.h"
using namespace vex;

//Variables
int Pre = 0;
double tileselect = 0;
int SideSelect = 0;
double Screen = 0;
double ProgSelect = 0;
int DriveSelect = 0;
int squareselect = 0;

void pre_auton( void ) {
	/*while(Pre==0){
		if(Screen == 0){
			Brain.Screen.clearScreen();
      TextChanger(2);
			Brain.Screen.setPenWidth(2);
			Brain.Screen.setPenColor(vex::color::blue);
			Brain.Screen.drawRectangle(165,10,300,220,vex::color::black);
			Brain.Screen.drawLine(175,60,455,60);
			Brain.Screen.drawRectangle(175,75,135,65,vex::color::black);
			Brain.Screen.drawRectangle(320,75,135,65,vex::color::black);
			Brain.Screen.drawRectangle(175,155,280,65,vex::color::black);
      Brain.Screen.drawRectangle(400,20,55,30,vex::color::black);
			Brain.Screen.setFont(vex::fontType::prop30);
			Brain.Screen.setPenColor("#C0C0C0");
			Brain.Screen.printAt(190,50,false,"Home");
			Brain.Screen.printAt(192,195,false,"System Diagnostics");
			Brain.Screen.setFont(vex::fontType::prop20);
      Brain.Screen.printAt(415,40,false,"Set");
			Brain.Screen.printAt(210,102,false,"Driver");
			Brain.Screen.printAt(200,122,false,"Selection");
			Brain.Screen.printAt(330,102,false,"Autonomous");
			Brain.Screen.printAt(345,122,false,"Selection");
      vex::task::sleep(500);
			while(Screen == 0){
				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 140 && Brain.Screen.yPosition() >75 && Brain.Screen.xPosition() <310 && Brain.Screen.xPosition() > 175){
					Screen = 1;
				}
				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 140 && Brain.Screen.yPosition() >75 && Brain.Screen.xPosition() < 455 && Brain.Screen.xPosition() > 320){
					Screen = 2;
				}
				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 220 && Brain.Screen.yPosition() >155 && Brain.Screen.xPosition() < 455 && Brain.Screen.xPosition() > 175){
					Screen = 3;
				}
        if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 50 && Brain.Screen.yPosition() >20 && Brain.Screen.xPosition() < 455 && Brain.Screen.xPosition() > 400){
          Brain.Screen.clearScreen();
          Pre = 1;
          break;
				}
			}
		}
		if(Screen == 1){ //Driver Select Screen
			vex::task::sleep(500);
			Brain.Screen.clearScreen();
			TextChanger(2);
			Brain.Screen.setPenWidth(2);
			Brain.Screen.setPenColor(vex::color::blue);
			Brain.Screen.drawRectangle(165,10,300,220,vex::color::black);
			Brain.Screen.drawLine(175,60,455,60);
			if(DriveSelect == 0){
				Brain.Screen.drawRectangle(175,75,135,145,vex::color::blue);
				Brain.Screen.drawRectangle(320,75,135,145,vex::color::black);
			}
			if(DriveSelect == 1){
				Brain.Screen.drawRectangle(175,75,135,145,vex::color::black);
				Brain.Screen.drawRectangle(320,75,135,145,vex::color::blue);
			}
			Brain.Screen.setPenColor("#C0C0C0");
			Brain.Screen.drawRectangle(425,20,30,30,vex::color::black);
			Brain.Screen.setFont(vex::fontType::prop30);
			Brain.Screen.printAt(190,50,false,"Driver Select");
			Brain.Screen.setFont(vex::fontType::prop60);
			Brain.Screen.printAt(220,170,false,"N");
			Brain.Screen.printAt(360,170,false,"D");
			Brain.Screen.setPenColor(vex::color::red);
			Brain.Screen.setPenWidth(4);
			Brain.Screen.drawLine(435,35,445,25);
			Brain.Screen.drawLine(435,35,445,45);
			while(Screen== 1){
				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 50 && Brain.Screen.yPosition() >20 && Brain.Screen.xPosition() <455 && Brain.Screen.xPosition() > 425){
					Screen = 0;
				}
				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 220 && Brain.Screen.yPosition() >75 && Brain.Screen.xPosition() <310 && Brain.Screen.xPosition() > 175 && DriveSelect != 0){
					DriveSelect = 0;
					Brain.Screen.setPenColor(vex::color::blue);
					Brain.Screen.drawRectangle(175,75,135,145,vex::color::blue);
					Brain.Screen.drawRectangle(320,75,135,145,vex::color::black);
					Brain.Screen.setPenColor("#C0C0C0");
					Brain.Screen.setFont(vex::fontType::prop60);
					Brain.Screen.printAt(220,170,false,"N");
					Brain.Screen.printAt(360,170,false,"D");
				}
				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 220 && Brain.Screen.yPosition() >75 && Brain.Screen.xPosition() <455 && Brain.Screen.xPosition() > 320 && DriveSelect != 1){
					DriveSelect = 1;
					Brain.Screen.setPenColor(vex::color::blue);
					Brain.Screen.drawRectangle(320,75,135,145,vex::color::blue);
					Brain.Screen.drawRectangle(175,75,135,145,vex::color::black);
					Brain.Screen.setPenColor("#C0C0C0");
					Brain.Screen.setFont(vex::fontType::prop60);
					Brain.Screen.printAt(220,170,false,"N");
					Brain.Screen.printAt(360,170,false,"D");
				}
			}
		}

		if(Screen == 2){ //Program Select Screen
			Brain.Screen.clearScreen();
			Brain.Screen.setPenWidth(2);
			Brain.Screen.setPenColor(vex::color::blue);
			Brain.Screen.drawRectangle(165,10,300,220,vex::color::black);
			Brain.Screen.drawLine(175,60,455,60);
			Brain.Screen.drawRectangle(175,75,135,65,vex::color::black);
			Brain.Screen.drawRectangle(175,155,135,65,vex::color::black);
			Brain.Screen.setFont(vex::fontType::prop20);
			Brain.Screen.setPenColor("#C0C0C0");
			Brain.Screen.drawRectangle(425,20,30,30,vex::color::black);
			Brain.Screen.printAt(225,105,false,"Blue");
			Brain.Screen.printAt(210,125,false,"Alliance");
			Brain.Screen.printAt(225,185,false,"Red");
			Brain.Screen.printAt(210,205,false,"Alliance");
			Brain.Screen.setFont(vex::fontType::prop30);
			Brain.Screen.printAt(190,50,false,"Auto Select");
			Brain.Screen.setPenColor(vex::color::red);
			Brain.Screen.setPenWidth(4);
			Brain.Screen.drawLine(435,35,445,25);
			Brain.Screen.drawLine(435,35,445,45);
			vex::task::sleep(500);
			while(Screen == 2 ){
				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 50 && Brain.Screen.yPosition() >20 && Brain.Screen.xPosition() <455 && Brain.Screen.xPosition() > 425){
					Screen = 0;
					SideSelect = 0;
				}
				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 140 && Brain.Screen.yPosition() >75 && Brain.Screen.xPosition() <310 && Brain.Screen.xPosition() > 175 && SideSelect != 1){
					SideSelect = 1;
                    tileselect = 0;
					BlueAuto();
				}
				if(Brain.Screen.pressing() == true && Brain.Screen.yPosition() < 220 && Brain.Screen.yPosition() >155 && Brain.Screen.xPosition() <310 && Brain.Screen.xPosition() > 175 && SideSelect != 2){
					SideSelect = 2;
                    tileselect = 0;
					RedAuto();
				}
				if(Brain.Screen.pressing() == true && tileselect != 1 && SideSelect == 1 && Brain.Screen.yPosition() < 81 && Brain.Screen.yPosition() >42 && Brain.Screen.xPosition() <160 && Brain.Screen.xPosition() > 111){
					tileselect = 1;
					BlueAuto();
                    AutoSelectB();
                    BTF();
					Brain.Screen.setPenWidth(2);
					Brain.Screen.setPenColor(vex::color::green);
					Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
				}
				if(Brain.Screen.pressing() == true && tileselect != 2 && SideSelect == 1 && Brain.Screen.yPosition() < 198 && Brain.Screen.yPosition() >159 && Brain.Screen.xPosition() <160 && Brain.Screen.xPosition() > 111){
					tileselect = 2;
					BlueAuto();
                    AutoSelectB();
                    BBF();
					Brain.Screen.setPenWidth(2);
					Brain.Screen.setPenColor(vex::color::green);
					Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
				}
				if(Brain.Screen.pressing() == true && tileselect != 3 && SideSelect == 2 && Brain.Screen.yPosition() < 81 && Brain.Screen.yPosition() >42 && Brain.Screen.xPosition() <160 && Brain.Screen.xPosition() > 111){
					tileselect = 3;
					RedAuto();
                    AutoSelectR();
                    RTF();
					Brain.Screen.setPenWidth(2);
					Brain.Screen.setPenColor(vex::color::green);
					Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
				}
				if(Brain.Screen.pressing() == true && tileselect != 4 && SideSelect == 2 && Brain.Screen.yPosition() < 198 && Brain.Screen.yPosition() >159 && Brain.Screen.xPosition() <160 && Brain.Screen.xPosition() > 111){
					tileselect = 4;
					RedAuto();
                    AutoSelectR();
                    RBF();
					Brain.Screen.setPenWidth(2);
					Brain.Screen.setPenColor(vex::color::green);
					Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
				}
                if(Brain.Screen.pressing() == true && squareselect != 1&& Brain.Screen.yPosition() < 110 && Brain.Screen.yPosition() >74 && Brain.Screen.xPosition() <455 && Brain.Screen.xPosition() > 320){
                    squareselect = 1;
                    if(tileselect == 1){
                        BlueAuto();
                        ProgSelect = 1.1;
                        AutoSelectB();
                        BTF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                    }
                    if(tileselect == 2){  
                        BlueAuto();
                        ProgSelect = 1.2;
                        AutoSelectB();
                        BBF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                    }
                    if(tileselect == 3){ 
                        RedAuto();
                        ProgSelect = 1.3;
                        AutoSelectR();
                        RTF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                    }
                    if(tileselect == 4){  
                        RedAuto();
                        ProgSelect = 1.4;
                        AutoSelectR();
                        RBF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                    }
                    Brain.Screen.setPenWidth(2);
					Brain.Screen.setPenColor(vex::color::green);
					Brain.Screen.drawRectangle(320,74,134,36,vex::color::transparent);
                }
                if(Brain.Screen.pressing() == true  && squareselect != 2&& Brain.Screen.yPosition() < 147 && Brain.Screen.yPosition() >110 && Brain.Screen.xPosition() <455 && Brain.Screen.xPosition() > 320){
                    squareselect = 2;
                    if(tileselect == 1){
                        BlueAuto();
                        ProgSelect = 2.1;
                        AutoSelectB();
                        BTF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                    }
                    if(tileselect == 2){  
                        BlueAuto();
                        ProgSelect = 2.2;
                        AutoSelectB();
                        BBF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                    }
                    if(tileselect == 3){ 
                        RedAuto();
                        ProgSelect = 2.3;
                        AutoSelectR();
                        RTF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                    }
                    if(tileselect == 4){  
                        RedAuto();
                        ProgSelect = 2.4;
                        AutoSelectR();
                        RBF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                    }
                    Brain.Screen.setPenWidth(2);
					Brain.Screen.setPenColor(vex::color::green);
					Brain.Screen.drawRectangle(320,110,134,36,vex::color::transparent);
                }
                if(Brain.Screen.pressing() == true  && squareselect != 3 && Brain.Screen.yPosition() < 185 && Brain.Screen.yPosition() >147 && Brain.Screen.xPosition() <455 && Brain.Screen.xPosition() > 320){
                   squareselect = 3;
                    if(tileselect == 1){
                        BlueAuto();
                        ProgSelect = 3.1;
                        AutoSelectB();
                        BTF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                    }
                    if(tileselect == 2){  
                        BlueAuto();
                        ProgSelect = 3.2;
                        AutoSelectB();
                        BBF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                    }
                    if(tileselect == 3){ 
                        RedAuto();
                        ProgSelect = 3.3;
                        AutoSelectR();
                        RTF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                    }
                    if(tileselect == 4){  
                        RedAuto();
                        ProgSelect = 3.4;
                        AutoSelectR();
                        RBF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                    }
                    Brain.Screen.setPenWidth(2);
					Brain.Screen.setPenColor(vex::color::green);
					Brain.Screen.drawRectangle(320,147,134,36,vex::color::transparent);
                }
                if(Brain.Screen.pressing() == true && squareselect != 4&& Brain.Screen.yPosition() < 215 && Brain.Screen.yPosition() >185 && Brain.Screen.xPosition() <455 && Brain.Screen.xPosition() > 320){
                    squareselect = 4;
                    if(tileselect == 1){
                        BlueAuto();
                        ProgSelect = 4.1;
                        AutoSelectB();
                        BTF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                    }
                    if(tileselect == 2){  
                        BlueAuto();
                        ProgSelect = 4.2;
                        AutoSelectB();
                        BBF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                    }
                    if(tileselect == 3){ 
                        RedAuto();
                        ProgSelect = 4.3;
                        AutoSelectR();
                        RTF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,42,48,39,vex::color::transparent);
                    }
                    if(tileselect == 4){  
                        RedAuto();
                        ProgSelect = 4.4;
                        AutoSelectR();
                        RBF();
                        Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					    Brain.Screen.drawRectangle(111,159,48,39,vex::color::transparent);
                    }
                    Brain.Screen.setPenWidth(2);
					    Brain.Screen.setPenColor(vex::color::green);
					Brain.Screen.drawRectangle(320,185,134,36,vex::color::transparent);
                }
			}
		}
		if(Screen == 3){ //Settings Screen
			while(Screen == 3){
		}
		}
	}*/
}

//Autonomus Function
void autonomous( void ) { //Initiates auto function
   /*if(ProgSelect == 1.1){ //Front Blue 1
   }
   if(ProgSelect == 2.1){//Front Blue 2
   }
   if(ProgSelect == 3.1){//Front Blue 3

   }
   if(ProgSelect == 4.1){//Front Blue 4

   }
   if(ProgSelect == 1.2){//Back Blue 1
   }
   if(ProgSelect == 2.2){//Back Blue 2

   }
   if(ProgSelect == 3.2){//Back Blue 3

   }
   if(ProgSelect == 4.2){//Back Blue 4
     
   }
   if(ProgSelect == 1.3){//Front Red 1
   }
   if(ProgSelect == 2.3){//Front Red 2

   }
   if(ProgSelect == 3.3){//Front Red 3

   }
   if(ProgSelect == 4.3){ //Front Red 4

   }
   if(ProgSelect == 1.4){//Back Red 1
   }
   if(ProgSelect == 2.4){//Back Red 2
     
   }
   if(ProgSelect == 3.4){//Back Red 3

   }
   if(ProgSelect == 4.4){//Back Red 4

   }*/
   /*
   Tilt.spin(vex::directionType::fwd,100,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
   vex::task::sleep(300);
   Tilt.spin(vex::directionType::rev,100,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
   vex::task::sleep(500);
   Tilt.stop(vex::brakeType::brake); //Lift Feeder stop
   Drive(100,5); 
   IFeed();
   Drive(60,40);
   vex::task::sleep(200);
   SFeed();
   Turn(100,2.5);
   vex::task::sleep(150);
   IFeed();
   Drive(125,10);
   vex::task::sleep(1000);
   SFeed();
   Drive(150,-10);
   vex::task::sleep(300);
   Turn(100,-2);
   Drive(100, 10);
   vex::task::sleep(500);
   SFeed();
   /
   Drive(200,-48);
   TDR(600);
   Drive(150,22.5);
   vex::task::sleep(500);
   Turn(100,-21);
   vex::task::sleep(500);
   Drive(150,16);
   /
   LL.spin(vex::directionType::rev,100,vex::velocityUnits::rpm); //Run Left Lift reversed at 100 rpm 
   RL.spin(vex::directionType::fwd,100,vex::velocityUnits::rpm);  //Run Right lift reversed at 100 rpm 
   vex::task::sleep(500);
   LL.stop(vex::brakeType::brake); //Stop Left Lift 
   RL.stop(vex::brakeType::brake); //Stop Right Lift
   *
   OFeed();
   vex::task::sleep(150);
   SFeed();
   UTilt(28,100);
   LFeed.spin(vex::directionType::fwd,10,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
   RFeed.spin(vex::directionType::rev,10,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
   Tilt.spin(vex::directionType::fwd,20,vex::velocityUnits::rpm);
   vex::task::sleep(1300);
   Tilt.stop(vex::brakeType::brake);
   OFeed();
   vex::task::sleep(750);
   Drive(50,-10);
   SFeed();
   
}

void usercontrol( void ) {
  while (1) {
   while(DriveSelect == 0){
   //Runs drive motors based off of contorller axis 
      CW.spin(vex::directionType::fwd, (Controller1.Axis4.value() - Controller1.Axis3.value()), vex::velocityUnits::pct);
      LB.spin(vex::directionType::fwd, (Controller1.Axis4.value() + Controller1.Axis3.value()), vex::velocityUnits::pct); 
      RB.spin(vex::directionType::fwd, (Controller1.Axis4.value() - Controller1.Axis3.value()), vex::velocityUnits::pct);
      
      //DR4B Lift 
      if(Controller1.ButtonR2.pressing()){ //Lift Up
        LL.spin(vex::directionType::fwd,100,vex::velocityUnits::rpm); //Run Left Lift at 100 rpm
        RL.spin(vex::directionType::rev,100,vex::velocityUnits::rpm); //Run Right Lift at 100 rpm
        }
      else if(Controller1.ButtonR1.pressing()){ 
          LL.spin(vex::directionType::rev,100,vex::velocityUnits::rpm); //Run Left Lift reversed at 100 rpm 
          RL.spin(vex::directionType::fwd,100,vex::velocityUnits::rpm);  //Run Right lift reversed at 100 rpm 
      }
      else{ //Stop Lift
        LL.stop(vex::brakeType::brake); //Stop Left Lift 
        RL.stop(vex::brakeType::brake); //Stop Right Lift 
      }

      //Intake
      if(Controller1.ButtonL1.pressing()){ //Run intake in
        LFeed.spin(vex::directionType::rev,200,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
        RFeed.spin(vex::directionType::fwd,200,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
      }
      else if(Controller1.ButtonL2.pressing()){ //Run intake out
        LFeed.spin(vex::directionType::fwd,200,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
        RFeed.spin(vex::directionType::rev,200,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
      }  
      else if(Controller1.ButtonB.pressing()){ //Run intake out
        LFeed.spin(vex::directionType::fwd,75,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
        RFeed.spin(vex::directionType::rev,75,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
      }
      else{
        RFeed.stop(vex::brakeType::hold); //Lift Feeder stop
        LFeed.stop(vex::brakeType::hold); //Lift Feeder stop
      }
      //Tiliter
      if(Controller1.ButtonX.pressing()){ //Run intake in
          if(TiltPot.value(vex::percentUnits::pct) >= 27){
            Tilt.spin(vex::directionType::fwd,100,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
          }
          if(TiltPot.value(vex::percentUnits::pct) <= 26){
            Tilt.spin(vex::directionType::fwd,20,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
          }
      }
      else if(Controller1.ButtonY.pressing()){ //Run intake out
        Tilt.spin(vex::directionType::rev,100,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
      }  
      else if(Controller1.ButtonA.pressing()){ //Run intake out
        Tilt.spin(vex::directionType::fwd,20,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
      } 
      else{
        Tilt.stop(vex::brakeType::brake); //Lift Feeder stop
      }
  }
  while(DriveSelect == 1){
   //Runs drive motors based off of contorller axis 
      CW.spin(vex::directionType::fwd, (Controller1.Axis3.value()), vex::velocityUnits::pct);
      LB.spin(vex::directionType::fwd, (Controller1.Axis4.value() + Controller1.Axis3.value()), vex::velocityUnits::pct); 
      RB.spin(vex::directionType::fwd, (Controller1.Axis4.value() - Controller1.Axis3.value()), vex::velocityUnits::pct);
      
      LL.spin(vex::directionType::fwd, (-Controller1.Axis2.value()), vex::velocityUnits::pct); 
      RL.spin(vex::directionType::fwd, (Controller1.Axis2.value()), vex::velocityUnits::pct);
      //DR4B Lift 

      //Intake
      if(Controller1.ButtonL1.pressing()){ //Run intake in
        LFeed.spin(vex::directionType::fwd,200,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
        RFeed.spin(vex::directionType::rev,200,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
      }
      else if(Controller1.ButtonL2.pressing()){ //Run intake out
        LFeed.spin(vex::directionType::rev,200,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
        RFeed.spin(vex::directionType::fwd,200,vex::velocityUnits::rpm);//Run Lift Feeder at 600 rpm
      }  
      else{
        LFeed.stop(vex::brakeType::coast); //Lift Feeder stop
        RFeed.stop(vex::brakeType::coast); //Lift Feeder stop
      }
      
  }
}
}

int main() {
    //Set up callbacks for autonomous and driver control periods.
    Competition.autonomous( autonomous );
    Competition.drivercontrol( usercontrol );
    
    //Run the pre-autonomous function. 
    pre_auton();
    //Prevent main from exiting with an infinite loop.                        
    while(1) {
      vex::task::sleep(100);//Sleep the task for a short amount of time to prevent wasted resources.
    }    
       
}
