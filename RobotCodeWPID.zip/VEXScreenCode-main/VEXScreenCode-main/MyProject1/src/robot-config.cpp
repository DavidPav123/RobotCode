#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor left_back_motor = motor(PORT1, ratio18_1, true);
motor left_front_motor = motor(PORT2, ratio18_1, false);
controller Controller1 = controller(primary);
rotation rotation_left = rotation(PORT21, true);
rotation rotation_right = rotation(PORT20, false);
motor right_front_motor = motor(PORT3, ratio18_1, false);
motor right_back_motor = motor(PORT4, ratio18_1, true);
motor lift_left = motor(PORT5, ratio36_1, true);
motor lift_right = motor(PORT6, ratio36_1, false);
motor intake = motor(PORT7, ratio6_1, false);
motor mobile_goal = motor(PORT8, ratio36_1, false);
pot mobo_potentiometer = pot(Brain.ThreeWirePort.B);
inertial inertial_sensor = inertial(PORT9);
digital_out pnuematic_left = digital_out(Brain.ThreeWirePort.C);
digital_out pnuematic_right = digital_out(Brain.ThreeWirePort.D);
distance intake_top = distance(PORT10);
distance intake_counter = distance(PORT11);
pot claw_potentiometer = pot(Brain.ThreeWirePort.E);
rotation lift_left_rotation = rotation(PORT12, false);
rotation lift_right_rotation = rotation(PORT13, false);
bumper lift_switch = bumper(Brain.ThreeWirePort.A);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}