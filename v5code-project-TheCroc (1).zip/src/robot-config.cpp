#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor left_back_motor = motor(PORT20, ratio18_1, true);
motor left_front_motor = motor(PORT19, ratio18_1, false);
controller Controller1 = controller(primary);
rotation rotation_left = rotation(PORT9, true);
rotation rotation_right = rotation(PORT15, false);
motor right_front_motor = motor(PORT11, ratio18_1, false);
motor right_back_motor = motor(PORT12, ratio18_1, true);
motor center_left = motor(PORT17, ratio18_1, false);
motor center_right = motor(PORT18, ratio18_1, false);
motor ringly_dingler = motor(PORT13, ratio36_1, false);
motor mobile_goal = motor(PORT14, ratio36_1, false);
pot mobo_pot = pot(Brain.ThreeWirePort.A);
digital_out center_shifter = digital_out(Brain.ThreeWirePort.B);
digital_out drive_speed_shifter = digital_out(Brain.ThreeWirePort.D);
digital_out ring_manipulator = digital_out(Brain.ThreeWirePort.C);
pot Ring_Pot = pot(Brain.ThreeWirePort.E);
bumper lift_switch = bumper(Brain.ThreeWirePort.F);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}